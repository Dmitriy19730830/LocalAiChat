# Сохраняем JNI-классы нетронутыми
-keep class com.example.localai.engine.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
