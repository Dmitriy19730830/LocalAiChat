// llama_jni.cpp
//
// Мост между Kotlin (LlamaBridge.kt) и llama.cpp.
//
// Два режима компиляции:
//   1) Обычный режим — если llama.cpp подключён как сабмодуль (см. CMakeLists.txt),
//      используется реальный API llama.cpp (llama.h) для инференса GGUF-моделей.
//   2) STUB_MODE — если llama.cpp не найден, библиотека всё равно собирается
//      и возвращает понятные тестовые ответы. Это позволяет разрабатывать и
//      тестировать UI/архитектуру приложения до того, как нативная модель подключена.
//
// Реальный API llama.cpp периодически меняется между версиями — если у вас
// другая версия сабмодуля, может понадобиться скорректировать имена функций
// (см. official examples/simple/simple.cpp в репозитории llama.cpp как эталон).

#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include <mutex>

#define LOG_TAG "LocalAI-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef STUB_MODE
#include "llama.h"
#include "clip.h"
#include "llava.h"
#endif

// ---------------------------------------------------------------------------
// Внутреннее состояние одной загруженной модели
// ---------------------------------------------------------------------------
struct ModelHandle {
#ifndef STUB_MODE
    llama_model* model = nullptr;
    llama_context* ctx = nullptr;
    const llama_vocab* vocab = nullptr;
    clip_ctx* clipCtx = nullptr; // CLIP-энкодер изображений (LLaVA/Moondream), nullptr если vision не подключён
#endif
    std::string modelPath;
    bool hasVision = false;
    int nCtx = 4096;
    int nThreads = 4;
};

static std::mutex g_mutex;

// ---------------------------------------------------------------------------
// Загрузка модели
// ---------------------------------------------------------------------------
extern "C" JNIEXPORT jlong JNICALL
Java_com_example_localai_engine_LlamaBridge_nativeLoadModel(
        JNIEnv* env, jobject /*thiz*/,
        jstring jModelPath, jstring jMmprojPath,
        jint nCtx, jint nThreads, jint nGpuLayers) {

    std::lock_guard<std::mutex> lock(g_mutex);

    const char* modelPathChars = env->GetStringUTFChars(jModelPath, nullptr);
    std::string modelPath(modelPathChars);
    env->ReleaseStringUTFChars(jModelPath, modelPathChars);

    std::string mmprojPath;
    if (jMmprojPath != nullptr) {
        const char* mmChars = env->GetStringUTFChars(jMmprojPath, nullptr);
        mmprojPath = std::string(mmChars);
        env->ReleaseStringUTFChars(jMmprojPath, mmChars);
    }

    auto* handle = new ModelHandle();
    handle->modelPath = modelPath;
    handle->nCtx = nCtx;
    handle->hasVision = !mmprojPath.empty();

#ifdef STUB_MODE
    LOGI("STUB_MODE: имитация загрузки модели %s", modelPath.c_str());
    (void) nThreads; (void) nGpuLayers;
    return reinterpret_cast<jlong>(handle);
#else
    llama_backend_init();

    llama_model_params modelParams = llama_model_default_params();
    modelParams.n_gpu_layers = nGpuLayers;

    handle->model = llama_model_load_from_file(modelPath.c_str(), modelParams);
    if (handle->model == nullptr) {
        LOGE("Не удалось загрузить модель: %s", modelPath.c_str());
        delete handle;
        return 0;
    }

    handle->vocab = llama_model_get_vocab(handle->model);

    llama_context_params ctxParams = llama_context_default_params();
    ctxParams.n_ctx = nCtx;
    ctxParams.n_threads = nThreads;
    ctxParams.n_threads_batch = nThreads;

    handle->ctx = llama_init_from_model(handle->model, ctxParams);
    if (handle->ctx == nullptr) {
        LOGE("Не удалось создать контекст инференса");
        llama_model_free(handle->model);
        delete handle;
        return 0;
    }

    // Vision: загружаем CLIP-проектор (mmproj), если он указан для этой модели.
    // Используется реализацией LLaVA/Moondream из examples/llava (clip.h).
    if (handle->hasVision) {
        // Второй параметр — verbosity (0 = тихо, 1 = базовый лог).
        handle->clipCtx = clip_model_load(mmprojPath.c_str(), /*verbosity=*/1);
        if (handle->clipCtx == nullptr) {
            LOGE("Не удалось загрузить CLIP-проектор: %s. Текстовая модель всё равно доступна.",
                 mmprojPath.c_str());
            handle->hasVision = false; // продолжаем без vision, не валим всю загрузку
        } else {
            LOGI("CLIP-проектор загружен: %s", mmprojPath.c_str());
        }
    }

    handle->nThreads = nThreads;
    LOGI("Модель загружена: %s (ctx=%d)", modelPath.c_str(), nCtx);
    return reinterpret_cast<jlong>(handle);
#endif
}

// ---------------------------------------------------------------------------
// Генерация текста (потоковая, через колбэк в Kotlin)
// ---------------------------------------------------------------------------
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_localai_engine_LlamaBridge_nativeGenerate(
        JNIEnv* env, jobject /*thiz*/,
        jlong handlePtr, jstring jPrompt, jstring jImagePath,
        jint maxTokens, jfloat temperature, jfloat topP, jint topK,
        jobject tokenCallback) {

    auto* handle = reinterpret_cast<ModelHandle*>(handlePtr);
    if (handle == nullptr) {
        return env->NewStringUTF("[Ошибка: модель не загружена]");
    }

    const char* promptChars = env->GetStringUTFChars(jPrompt, nullptr);
    std::string prompt(promptChars);
    env->ReleaseStringUTFChars(jPrompt, promptChars);

    bool hasImage = jImagePath != nullptr;
    std::string imagePath;
    if (hasImage) {
        const char* imgChars = env->GetStringUTFChars(jImagePath, nullptr);
        imagePath = std::string(imgChars);
        env->ReleaseStringUTFChars(jImagePath, imgChars);
    }

    // Подготовка вызова Kotlin-колбэка onToken(String): Boolean для потоковой выдачи
    jclass callbackClass = env->GetObjectClass(tokenCallback);
    jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;)Z");

    auto emitToken = [&](const std::string& token) -> bool {
        jstring jToken = env->NewStringUTF(token.c_str());
        jboolean keepGoing = env->CallBooleanMethod(tokenCallback, onTokenMethod, jToken);
        env->DeleteLocalRef(jToken);
        return keepGoing == JNI_TRUE;
    };

#ifdef STUB_MODE
    (void) maxTokens; (void) temperature; (void) topP; (void) topK;
    std::string stub = hasImage
        ? "[STUB] Получено изображение (" + imagePath + ") и запрос: \"" + prompt +
          "\". Подключите llama.cpp + LLaVA mmproj для реального анализа."
        : "[STUB] Эхо-ответ на запрос: \"" + prompt +
          "\". Подключите llama.cpp (см. CMakeLists.txt), чтобы получать настоящие ответы модели.";

    // Имитация потоковой генерации по словам
    std::string word;
    for (char c : stub) {
        word += c;
        if (c == ' ') {
            if (!emitToken(word)) break;
            word.clear();
        }
    }
    if (!word.empty()) emitToken(word);
    return env->NewStringUTF(stub.c_str());
#else
    if (handle->ctx == nullptr || handle->vocab == nullptr) {
        return env->NewStringUTF("[Ошибка: контекст не инициализирован]");
    }

    // ---- Vision: если есть изображение и CLIP-проектор загружен — кодируем
    // изображение и подмешиваем эмбеддинги в контекст ДО текста промпта ----
    int nPast = 0;
    if (hasImage) {
        if (handle->clipCtx == nullptr) {
            return env->NewStringUTF(
                "[Ошибка: для этой модели не загружен vision-проектор (mmproj). "
                "Скачайте vision-модель в Настройки → Модели.]");
        }

        llava_image_embed* imageEmbed = llava_image_embed_make_with_filename(
            handle->clipCtx, handle->nThreads, imagePath.c_str());
        if (imageEmbed == nullptr) {
            return env->NewStringUTF("[Ошибка: не удалось прочитать/закодировать изображение]");
        }

        // n_batch=512 — стандартный размер батча для прогона эмбеддингов через decode,
        // llava_eval_image_embed сам разбивает эмбеддинги на под-батчи нужного размера.
        bool ok = llava_eval_image_embed(handle->ctx, imageEmbed, /*n_batch=*/512, &nPast);
        llava_image_embed_free(imageEmbed);

        if (!ok) {
            return env->NewStringUTF("[Ошибка: не удалось декодировать эмбеддинги изображения]");
        }
        LOGI("Изображение закодировано, nPast=%d", nPast);
    }

    std::vector<llama_token> tokens(prompt.size() + 8);
    int nTokens = llama_tokenize(
            handle->vocab, prompt.c_str(), (int32_t) prompt.size(),
            tokens.data(), (int32_t) tokens.size(), true, true);
    if (nTokens < 0) {
        tokens.resize(-nTokens);
        nTokens = llama_tokenize(
                handle->vocab, prompt.c_str(), (int32_t) prompt.size(),
                tokens.data(), (int32_t) tokens.size(), true, true);
    }
    tokens.resize(nTokens);

    llama_batch batch = llama_batch_init(std::max((int) tokens.size(), maxTokens), 0, 1);
    for (int i = 0; i < nTokens; i++) {
        batch.token[i] = tokens[i];
        batch.pos[i] = nPast + i; // продолжаем позиции после эмбеддингов изображения (если были)
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == nTokens - 1);
    }
    batch.n_tokens = nTokens;

    if (llama_decode(handle->ctx, batch) != 0) {
        llama_batch_free(batch);
        return env->NewStringUTF("[Ошибка декодирования промпта]");
    }

    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(topK));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(topP, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string result;
    int nCur = nPast + nTokens;
    for (int i = 0; i < maxTokens; i++) {
        llama_token newToken = llama_sampler_sample(sampler, handle->ctx, -1);

        if (llama_vocab_is_eog(handle->vocab, newToken)) break;

        char buf[256];
        int n = llama_token_to_piece(handle->vocab, newToken, buf, sizeof(buf), 0, true);
        std::string piece(buf, n > 0 ? n : 0);
        result += piece;
        if (!emitToken(piece)) break;

        llama_batch nextBatch = llama_batch_init(1, 0, 1);
        nextBatch.token[0] = newToken;
        nextBatch.pos[0] = nCur;
        nextBatch.n_seq_id[0] = 1;
        nextBatch.seq_id[0][0] = 0;
        nextBatch.logits[0] = true;
        nextBatch.n_tokens = 1;

        if (llama_decode(handle->ctx, nextBatch) != 0) {
            llama_batch_free(nextBatch);
            break;
        }
        llama_batch_free(nextBatch);
        nCur++;
    }

    llama_sampler_free(sampler);
    llama_batch_free(batch);
    return env->NewStringUTF(result.c_str());
#endif
}

// ---------------------------------------------------------------------------
// Освобождение ресурсов модели
// ---------------------------------------------------------------------------
extern "C" JNIEXPORT void JNICALL
Java_com_example_localai_engine_LlamaBridge_nativeFreeModel(
        JNIEnv* /*env*/, jobject /*thiz*/, jlong handlePtr) {

    std::lock_guard<std::mutex> lock(g_mutex);
    auto* handle = reinterpret_cast<ModelHandle*>(handlePtr);
    if (handle == nullptr) return;

#ifndef STUB_MODE
    if (handle->clipCtx) clip_free(handle->clipCtx);
    if (handle->ctx) llama_free(handle->ctx);
    if (handle->model) llama_model_free(handle->model);
#endif
    delete handle;
}
