package com.example.localai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.localai.data.ModelConfig

@Composable
fun SettingsPanel(
    config: ModelConfig,
    systemPromptPresets: List<Pair<String, String>>,
    onConfigChange: (ModelConfig) -> Unit,
    onOpenModelManager: () -> Unit
) {
    var temperature by remember(config) { mutableFloatStateOf(config.temperature) }
    var topP by remember(config) { mutableFloatStateOf(config.topP) }
    var systemPrompt by remember(config) { mutableStateOf(config.systemPrompt) }
    var presetExpanded by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Настройки генерации", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            Button(onClick = onOpenModelManager, modifier = Modifier.fillMaxWidth()) {
                Text("Управление моделями (скачать / выбрать)")
            }

            Spacer(Modifier.height(16.dp))
            Text("Температура: ${"%.2f".format(temperature)}")
            Slider(
                value = temperature,
                onValueChange = {
                    temperature = it
                    onConfigChange(config.copy(temperature = it))
                },
                valueRange = 0.1f..1.5f
            )

            Text("Top-p: ${"%.2f".format(topP)}")
            Slider(
                value = topP,
                onValueChange = {
                    topP = it
                    onConfigChange(config.copy(topP = it))
                },
                valueRange = 0.1f..1.0f
            )

            Spacer(Modifier.height(8.dp))
            ExposedDropdownMenuBox(
                expanded = presetExpanded,
                onExpandedChange = { presetExpanded = it }
            ) {
                OutlinedTextField(
                    value = "Готовые промпты",
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    label = { Text("Шаблон системного промпта") }
                )
                ExposedDropdownMenu(expanded = presetExpanded, onDismissRequest = { presetExpanded = false }) {
                    systemPromptPresets.forEach { (name, text) ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                systemPrompt = text
                                onConfigChange(config.copy(systemPrompt = text))
                                presetExpanded = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = systemPrompt,
                onValueChange = {
                    systemPrompt = it
                    onConfigChange(config.copy(systemPrompt = it))
                },
                label = { Text("Системный промпт") },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                minLines = 2
            )
        }
    }
}
