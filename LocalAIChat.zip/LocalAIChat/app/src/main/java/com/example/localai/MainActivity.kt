package com.example.localai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.localai.engine.LocalAIEngine
import com.example.localai.ui.ChatApp
import com.example.localai.ui.theme.LocalAITheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val engine = remember { LocalAIEngine(applicationContext) }

            LocalAITheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ChatApp(engine)
                }
            }
        }
    }
}
