package com.example.localai.engine

import android.content.Context
import com.example.localai.data.ChatMessage
import com.example.localai.data.ModelConfig
import com.example.localai.data.ModelInfo
import com.example.localai.util.HistoryStorage
import com.example.localai.util.ManifestLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Управляет жизненным циклом загруженной llama.cpp-модели и генерацией ответов.
 * Поддерживает "бесконечный" контекст за счёт скользящего окна последних N сообщений
 * (config.slidingWindowMessages), чтобы не превышать n_ctx модели.
 */
class LocalAIEngine(private val context: Context) {

    private val bridge = LlamaBridge()
    val downloadManager = ModelDownloadManager(context)
    private val storage = HistoryStorage(context)

    var config: ModelConfig = storage.loadConfig()
        private set

    private var modelHandle: Long = 0
    private var loadedModelName: String? = null
    private var loadedHasVision: Boolean = false

    val availableLlmModels: List<ModelInfo> = ManifestLoader.loadLlmModels(context)
    val availableVisionModels: List<ModelInfo> = ManifestLoader.loadVisionModels(context)

    fun updateConfig(newConfig: ModelConfig) {
        config = newConfig
        storage.saveConfig(config)
    }

    fun loadHistory(): List<ChatMessage> = storage.loadHistory()
    fun saveHistory(messages: List<ChatMessage>) = storage.saveHistory(messages)
    fun clearHistory() = storage.clearHistory()
    fun systemPromptPresets() = storage.loadSystemPrompts()

    /** Загружает (или переиспользует, если уже загружена) текстовую + опционально vision-модель. */
    suspend fun ensureModelLoaded(useVision: Boolean): Boolean = withContext(Dispatchers.IO) {
        val targetName = if (useVision) config.visionModel else config.modelName
        if (modelHandle != 0L && loadedModelName == targetName && loadedHasVision == useVision) {
            return@withContext true // уже загружена нужная модель
        }

        val info = (if (useVision) availableVisionModels else availableLlmModels)
            .find { it.name == targetName } ?: return@withContext false

        if (!downloadManager.isDownloaded(info)) return@withContext false

        // Выгружаем предыдущую модель перед загрузкой новой (на устройстве обычно мало RAM)
        if (modelHandle != 0L) {
            bridge.nativeFreeModel(modelHandle)
            modelHandle = 0
        }

        val modelPath = downloadManager.localFile(info).absolutePath
        val mmprojPath = downloadManager.localMmprojFile(info)?.takeIf { it.exists() }?.absolutePath

        val handle = bridge.nativeLoadModel(
            modelPath, mmprojPath, config.contextSize, config.threads, config.gpuLayers
        )
        if (handle == 0L) return@withContext false

        modelHandle = handle
        loadedModelName = targetName
        loadedHasVision = useVision
        true
    }

    fun unloadModel() {
        if (modelHandle != 0L) {
            bridge.nativeFreeModel(modelHandle)
            modelHandle = 0
            loadedModelName = null
        }
    }

    /**
     * Генерирует ответ ассистента. [onToken] вызывается по мере поступления токенов
     * (потоковый вывод в UI), итоговая строка возвращается также целиком.
     */
    suspend fun generateResponse(
        userPrompt: String,
        imagePath: String?,
        history: List<ChatMessage>,
        onToken: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val useVision = imagePath != null
        val modelReady = ensureModelLoaded(useVision)
        if (!modelReady) {
            val msg = if (useVision)
                "Vision-модель не загружена. Зайдите в Настройки → Модели и скачайте vision-модель."
            else
                "Модель не загружена. Зайдите в Настройки → Модели и скачайте LLM-модель."
            onToken(msg)
            return@withContext msg
        }

        val fullPrompt = buildPrompt(history, userPrompt)

        val callback = object : LlamaBridge.TokenCallback {
            override fun onToken(token: String): Boolean {
                onToken(token)
                return true // true = продолжать генерацию
            }
        }

        bridge.nativeGenerate(
            modelHandle, fullPrompt, imagePath,
            config.maxTokens, config.temperature, config.topP, config.topK,
            callback
        )
    }

    /**
     * Скользящее окно контекста: берём системный промпт + последние N сообщений,
     * чтобы общий объём не превышал n_ctx модели, но при этом диалог мог
     * продолжаться сколь угодно долго ("бесконечная" история на диске).
     */
    private fun buildPrompt(history: List<ChatMessage>, userPrompt: String): String {
        val sb = StringBuilder()
        sb.append("<|system|>\n").append(config.systemPrompt).append("\n")

        val windowed = history.takeLast(config.slidingWindowMessages)
        windowed.forEach { msg ->
            val tag = if (msg.role == "user") "user" else "assistant"
            sb.append("<|$tag|>\n").append(msg.content).append("\n")
        }
        sb.append("<|user|>\n").append(userPrompt).append("\n<|assistant|>\n")
        return sb.toString()
    }
}
