package com.example.localai.util

import android.content.Context
import com.example.localai.data.ModelInfo
import org.json.JSONObject

object ManifestLoader {

    fun loadLlmModels(context: Context): List<ModelInfo> =
        loadSection(context, "llm_models", isVision = false)

    fun loadVisionModels(context: Context): List<ModelInfo> =
        loadSection(context, "vision_models", isVision = true)

    private fun loadSection(context: Context, key: String, isVision: Boolean): List<ModelInfo> {
        return try {
            val text = context.assets.open("models_manifest.json").bufferedReader().readText()
            val arr = JSONObject(text).getJSONArray(key)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                ModelInfo(
                    name = obj.getString("name"),
                    displayName = obj.optString("displayName", obj.getString("name")),
                    url = obj.getString("url"),
                    mmprojUrl = obj.optString("mmprojUrl").takeIf { it.isNotEmpty() },
                    sizeMB = obj.optInt("sizeMB", 0),
                    isVision = isVision
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
