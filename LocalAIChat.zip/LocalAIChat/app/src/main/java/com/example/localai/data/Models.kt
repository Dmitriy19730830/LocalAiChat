package com.example.localai.data

import org.json.JSONObject

/** Одно сообщение в чате. */
data class ChatMessage(
    val role: String, // "system" | "user" | "assistant"
    val content: String,
    val imageUri: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("role", role)
        put("content", content)
        put("imageUri", imageUri ?: JSONObject.NULL)
        put("timestamp", timestamp)
    }

    companion object {
        fun fromJson(obj: JSONObject): ChatMessage = ChatMessage(
            role = obj.getString("role"),
            content = obj.getString("content"),
            imageUri = obj.optString("imageUri").takeIf { it.isNotEmpty() && it != "null" },
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}

/** Параметры генерации и текущая выбранная модель. Сериализуется в config.json во internal storage. */
data class ModelConfig(
    var modelName: String = "qwen2.5-1.5b-instruct-q4_k_m",
    var visionModel: String = "llava-v1.6-mistral-7b-q4_k_m",
    var temperature: Float = 0.7f,
    var topP: Float = 0.9f,
    var topK: Int = 40,
    var maxTokens: Int = 1024,
    var contextSize: Int = 4096,
    var slidingWindowMessages: Int = 20,
    var threads: Int = 4,
    var gpuLayers: Int = 0,
    var systemPrompt: String = "Ты полезный ассистент с машинным зрением."
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("modelName", modelName)
        put("visionModel", visionModel)
        put("temperature", temperature.toDouble())
        put("topP", topP.toDouble())
        put("topK", topK)
        put("maxTokens", maxTokens)
        put("contextSize", contextSize)
        put("slidingWindowMessages", slidingWindowMessages)
        put("threads", threads)
        put("gpuLayers", gpuLayers)
        put("systemPrompt", systemPrompt)
    }

    companion object {
        fun fromJson(obj: JSONObject): ModelConfig = ModelConfig(
            modelName = obj.optString("modelName", "qwen2.5-1.5b-instruct-q4_k_m"),
            visionModel = obj.optString("visionModel", "llava-v1.6-mistral-7b-q4_k_m"),
            temperature = obj.optDouble("temperature", 0.7).toFloat(),
            topP = obj.optDouble("topP", 0.9).toFloat(),
            topK = obj.optInt("topK", 40),
            maxTokens = obj.optInt("maxTokens", 1024),
            contextSize = obj.optInt("contextSize", 4096),
            slidingWindowMessages = obj.optInt("slidingWindowMessages", 20),
            threads = obj.optInt("threads", 4),
            gpuLayers = obj.optInt("gpuLayers", 0),
            systemPrompt = obj.optString("systemPrompt", "Ты полезный ассистент.")
        )
    }
}

/** Описание модели из models_manifest.json */
data class ModelInfo(
    val name: String,
    val displayName: String,
    val url: String,
    val mmprojUrl: String? = null, // для vision-моделей (CLIP-проектор)
    val sizeMB: Int,
    val isVision: Boolean = false
)

enum class DownloadStatus { NOT_DOWNLOADED, DOWNLOADING, DOWNLOADED, ERROR }

data class ModelDownloadState(
    val info: ModelInfo,
    val status: DownloadStatus = DownloadStatus.NOT_DOWNLOADED,
    val progress: Float = 0f,
    val errorMessage: String? = null
)
