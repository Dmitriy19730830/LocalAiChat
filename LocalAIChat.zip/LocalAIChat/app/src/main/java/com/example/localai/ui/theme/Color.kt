package com.example.localai.ui.theme

import androidx.compose.ui.graphics.Color

val AccentBlue = Color(0xFF3D7BFF)
val AccentBlueDark = Color(0xFF1F4FCC)
val SurfaceLight = Color(0xFFF6F7FB)
val SurfaceDark = Color(0xFF14161C)
val BubbleUserLight = Color(0xFF3D7BFF)
val BubbleAssistantLight = Color(0xFFE9EBF2)
val BubbleUserDark = Color(0xFF3D7BFF)
val BubbleAssistantDark = Color(0xFF22252E)
