package com.example.localai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.localai.data.DownloadStatus
import com.example.localai.data.ModelInfo
import com.example.localai.engine.ModelDownloadManager
import kotlinx.coroutines.launch

@Composable
fun ModelManagerScreen(
    llmModels: List<ModelInfo>,
    visionModels: List<ModelInfo>,
    downloadManager: ModelDownloadManager,
    selectedLlm: String,
    selectedVision: String,
    onSelectLlm: (String) -> Unit,
    onSelectVision: (String) -> Unit
) {
    val states by downloadManager.states.collectAsState()
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                "Текстовые модели (LLM)",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        items(llmModels) { info ->
            ModelRow(
                info = info,
                isSelected = info.name == selectedLlm,
                status = states[info.name]?.status
                    ?: if (downloadManager.isDownloaded(info)) DownloadStatus.DOWNLOADED else DownloadStatus.NOT_DOWNLOADED,
                progress = states[info.name]?.progress ?: 0f,
                onSelect = { onSelectLlm(info.name) },
                onDownload = { scope.launch { downloadManager.download(info) } },
                onDelete = { downloadManager.delete(info) }
            )
        }

        item {
            Text(
                "Vision-модели (анализ изображений)",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
        items(visionModels) { info ->
            ModelRow(
                info = info,
                isSelected = info.name == selectedVision,
                status = states[info.name]?.status
                    ?: if (downloadManager.isDownloaded(info)) DownloadStatus.DOWNLOADED else DownloadStatus.NOT_DOWNLOADED,
                progress = states[info.name]?.progress ?: 0f,
                onSelect = { onSelectVision(info.name) },
                onDownload = { scope.launch { downloadManager.download(info) } },
                onDelete = { downloadManager.delete(info) }
            )
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun ModelRow(
    info: ModelInfo,
    isSelected: Boolean,
    status: DownloadStatus,
    progress: Float,
    onSelect: () -> Unit,
    onDownload: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = isSelected, onClick = onSelect, enabled = status == DownloadStatus.DOWNLOADED)
                Column(Modifier.weight(1f)) {
                    Text(info.displayName, style = MaterialTheme.typography.bodyLarge)
                    Text("${info.sizeMB} МБ", style = MaterialTheme.typography.labelSmall)
                }

                when (status) {
                    DownloadStatus.NOT_DOWNLOADED -> IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, contentDescription = "Скачать")
                    }
                    DownloadStatus.DOWNLOADING -> CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.size(28.dp)
                    )
                    DownloadStatus.DOWNLOADED -> Row {
                        Icon(Icons.Default.Check, contentDescription = "Скачано")
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить")
                        }
                    }
                    DownloadStatus.ERROR -> IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, contentDescription = "Повторить")
                    }
                }
            }
            if (status == DownloadStatus.DOWNLOADING) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
            }
        }
    }
}
