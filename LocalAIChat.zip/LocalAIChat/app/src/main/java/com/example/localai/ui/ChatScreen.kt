package com.example.localai.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.localai.engine.LocalAIEngine
import kotlinx.coroutines.launch
import java.io.File

private enum class Screen { CHAT, SETTINGS, MODELS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatApp(engine: LocalAIEngine) {
    val viewModel: ChatViewModel = viewModel(factory = ChatViewModel.Factory(engine))
    var screen by remember { mutableStateOf(Screen.CHAT) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (screen) {
                            Screen.CHAT -> "Local AI Chat"
                            Screen.SETTINGS -> "Настройки"
                            Screen.MODELS -> "Модели"
                        }
                    )
                },
                navigationIcon = {
                    if (screen != Screen.CHAT) {
                        IconButton(onClick = { screen = Screen.CHAT }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                        }
                    }
                },
                actions = {
                    if (screen == Screen.CHAT) {
                        IconButton(onClick = { screen = Screen.SETTINGS }) {
                            Icon(Icons.Default.Settings, contentDescription = "Настройки")
                        }
                        IconButton(onClick = { viewModel.clearHistory() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Очистить историю")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (screen) {
                Screen.CHAT -> ChatScreen(viewModel)
                Screen.SETTINGS -> SettingsPanel(
                    config = viewModel.configState.value,
                    systemPromptPresets = engine.systemPromptPresets(),
                    onConfigChange = { viewModel.updateConfig(it) },
                    onOpenModelManager = { screen = Screen.MODELS }
                )
                Screen.MODELS -> ModelManagerScreen(
                    llmModels = engine.availableLlmModels,
                    visionModels = engine.availableVisionModels,
                    downloadManager = engine.downloadManager,
                    selectedLlm = viewModel.configState.value.modelName,
                    selectedVision = viewModel.configState.value.visionModel,
                    onSelectLlm = { viewModel.updateConfig(viewModel.configState.value.copy(modelName = it)) },
                    onSelectVision = { viewModel.updateConfig(viewModel.configState.value.copy(visionModel = it)) }
                )
            }
        }
    }
}

@Composable
private fun ChatScreen(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var inputText by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    val listState = rememberLazyListState()

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) selectedImageUri = uri }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success -> if (success) selectedImageUri = pendingCameraUri }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = createTempImageUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        }
    }

    LaunchedEffect(viewModel.messages.size) {
        if (viewModel.messages.isNotEmpty()) {
            listState.animateScrollToItem(viewModel.messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(viewModel.messages) { msg -> MessageBubble(msg) }
        }

        selectedImageUri?.let { uri ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                coil.compose.AsyncImage(
                    model = uri, contentDescription = null,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Изображение прикреплено", modifier = Modifier.weight(1f))
                IconButton(onClick = { selectedImageUri = null }) {
                    Icon(Icons.Default.Close, contentDescription = "Убрать")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = {
                cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
            }) {
                Icon(Icons.Default.PhotoCamera, contentDescription = "Камера")
            }
            IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                Icon(Icons.Default.Image, contentDescription = "Галерея")
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение…") },
                enabled = !viewModel.isGenerating.value
            )

            IconButton(
                enabled = !viewModel.isGenerating.value && (inputText.isNotBlank() || selectedImageUri != null),
                onClick = {
                    val text = inputText
                    val imageUriString = selectedImageUri?.toString()
                    inputText = ""
                    selectedImageUri = null
                    scope.launch { viewModel.sendMessage(text, imageUriString) }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "Отправить")
            }
        }
    }
}

private fun createTempImageUri(context: android.content.Context): Uri {
    val imagesDir = File(context.cacheDir, "images").apply { mkdirs() }
    val file = File(imagesDir, "camera_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
