package com.example.localai.ui

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.localai.data.ChatMessage
import com.example.localai.engine.LocalAIEngine
import kotlinx.coroutines.launch

class ChatViewModel(private val engine: LocalAIEngine) : ViewModel() {

    val messages = mutableStateListOf<ChatMessage>()
    val isGenerating = mutableStateOf(false)
    val configState = mutableStateOf(engine.config)

    init {
        val saved = engine.loadHistory()
        if (saved.isNotEmpty()) {
            messages.addAll(saved)
        } else {
            messages.add(
                ChatMessage(
                    role = "assistant",
                    content = "Привет! Я локальный ИИ-ассистент с поддержкой изображений. " +
                        "Откройте Настройки → Модели, чтобы скачать модель перед началом общения."
                )
            )
        }
    }

    fun sendMessage(text: String, imageUri: String?) {
        if (text.isBlank() && imageUri == null) return

        val userMsg = ChatMessage(role = "user", content = text, imageUri = imageUri)
        messages.add(userMsg)
        persist()

        val assistantIndex = messages.size
        messages.add(ChatMessage(role = "assistant", content = ""))
        isGenerating.value = true

        viewModelScope.launch {
            val finalText = engine.generateResponse(
                userPrompt = text,
                imagePath = imageUri,
                history = messages.toList().dropLast(1)
            ) { token ->
                val current = messages[assistantIndex]
                messages[assistantIndex] = current.copy(content = current.content + token)
            }
            messages[assistantIndex] = messages[assistantIndex].copy(content = finalText)
            isGenerating.value = false
            persist()
        }
    }

    fun updateConfig(newConfig: com.example.localai.data.ModelConfig) {
        engine.updateConfig(newConfig)
        configState.value = newConfig
    }

    fun clearHistory() {
        messages.clear()
        engine.clearHistory()
        messages.add(ChatMessage(role = "assistant", content = "История очищена. Задайте новый вопрос."))
    }

    private fun persist() {
        engine.saveHistory(messages.toList())
    }

    class Factory(private val engine: LocalAIEngine) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatViewModel(engine) as T
    }
}
