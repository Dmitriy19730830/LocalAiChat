package com.example.localai.engine

/**
 * Тонкий слой поверх JNI. Методы здесь напрямую соответствуют функциям
 * в app/src/main/cpp/llama_jni.cpp — не переименовывайте без правки обеих сторон.
 */
class LlamaBridge {

    companion object {
        init {
            System.loadLibrary("localai_native")
        }
    }

    /** Колбэк для потоковой генерации. Возврат false — остановить генерацию досрочно. */
    interface TokenCallback {
        fun onToken(token: String): Boolean
    }

    /** @return handle (указатель) на загруженную модель, либо 0 при ошибке. */
    external fun nativeLoadModel(
        modelPath: String,
        mmprojPath: String?,
        nCtx: Int,
        nThreads: Int,
        nGpuLayers: Int
    ): Long

    external fun nativeGenerate(
        handle: Long,
        prompt: String,
        imagePath: String?,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        callback: TokenCallback
    ): String

    external fun nativeFreeModel(handle: Long)
}
