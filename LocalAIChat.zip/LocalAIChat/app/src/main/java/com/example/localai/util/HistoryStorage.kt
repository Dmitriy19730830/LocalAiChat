package com.example.localai.util

import android.content.Context
import com.example.localai.data.ChatMessage
import com.example.localai.data.ModelConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Простое файловое хранилище: история чата и конфиг — обычные JSON-файлы во internal storage. */
class HistoryStorage(private val context: Context) {

    private val historyFile get() = File(context.filesDir, "chat_history.json")
    private val configFile get() = File(context.filesDir, "config.json")

    fun saveHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.forEach { arr.put(it.toJson()) }
        historyFile.writeText(arr.toString())
    }

    fun loadHistory(): List<ChatMessage> {
        if (!historyFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(historyFile.readText())
            (0 until arr.length()).map { ChatMessage.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearHistory() {
        historyFile.delete()
    }

    fun saveConfig(config: ModelConfig) {
        configFile.writeText(config.toJson().toString())
    }

    /** При первом запуске читает config.json из assets/, дальше — из internal storage. */
    fun loadConfig(): ModelConfig {
        if (configFile.exists()) {
            return try {
                ModelConfig.fromJson(JSONObject(configFile.readText()))
            } catch (e: Exception) {
                ModelConfig()
            }
        }
        return try {
            val text = context.assets.open("config.json").bufferedReader().readText()
            ModelConfig.fromJson(JSONObject(text))
        } catch (e: Exception) {
            ModelConfig()
        }
    }

    fun loadSystemPrompts(): List<Pair<String, String>> {
        return try {
            val text = context.assets.open("system_prompts.json").bufferedReader().readText()
            val arr = JSONObject(text).getJSONArray("prompts")
            (0 until arr.length()).map {
                val obj = arr.getJSONObject(it)
                obj.getString("name") to obj.getString("text")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
