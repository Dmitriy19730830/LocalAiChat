package com.example.localai.engine

import android.content.Context
import com.example.localai.data.DownloadStatus
import com.example.localai.data.ModelDownloadState
import com.example.localai.data.ModelInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

/**
 * Скачивает .gguf файлы моделей (и mmproj для vision) в [context.filesDir]/models/
 * с поддержкой докачки (Range-запросы) и отслеживанием прогресса через StateFlow.
 */
class ModelDownloadManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // большие файлы — без таймаута на чтение
        .build()

    private val modelsDir: File
        get() = File(context.filesDir, "models").apply { mkdirs() }

    private val _states = MutableStateFlow<Map<String, ModelDownloadState>>(emptyMap())
    val states: StateFlow<Map<String, ModelDownloadState>> = _states

    fun localFile(info: ModelInfo): File = File(modelsDir, "${info.name}.gguf")
    fun localMmprojFile(info: ModelInfo): File? =
        info.mmprojUrl?.let { File(modelsDir, "${info.name}.mmproj.gguf") }

    fun isDownloaded(info: ModelInfo): Boolean {
        val mainOk = localFile(info).exists() && localFile(info).length() > 0
        val mmprojOk = info.mmprojUrl == null || (localMmprojFile(info)?.exists() == true)
        return mainOk && mmprojOk
    }

    /** Скачивает основной файл модели и (если задан) mmproj-проектор для vision. */
    suspend fun download(info: ModelInfo) {
        updateState(info) { it.copy(status = DownloadStatus.DOWNLOADING, progress = 0f, errorMessage = null) }
        try {
            downloadFile(info.url, localFile(info)) { progress ->
                updateState(info) { it.copy(progress = progress) }
            }
            info.mmprojUrl?.let { url ->
                localMmprojFile(info)?.let { dest ->
                    downloadFile(url, dest) { progress ->
                        updateState(info) { it.copy(progress = progress) }
                    }
                }
            }
            updateState(info) { it.copy(status = DownloadStatus.DOWNLOADED, progress = 1f) }
        } catch (e: Exception) {
            updateState(info) {
                it.copy(status = DownloadStatus.ERROR, errorMessage = e.message ?: "Ошибка загрузки")
            }
        }
    }

    fun delete(info: ModelInfo) {
        localFile(info).delete()
        localMmprojFile(info)?.delete()
        updateState(info) { it.copy(status = DownloadStatus.NOT_DOWNLOADED, progress = 0f) }
    }

    private fun downloadFile(url: String, dest: File, onProgress: (Float) -> Unit) {
        val tmp = File(dest.parentFile, dest.name + ".part")
        val existingBytes = if (tmp.exists()) tmp.length() else 0L

        val requestBuilder = Request.Builder().url(url)
        if (existingBytes > 0) {
            requestBuilder.header("Range", "bytes=$existingBytes-")
        }

        client.newCall(requestBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code} для $url")

            val body = response.body ?: throw java.io.IOException("Пустой ответ сервера")
            val totalBytes = body.contentLength() + existingBytes
            val resumed = response.code == 206

            RandomAccessFile(tmp, "rw").use { raf ->
                if (resumed) raf.seek(existingBytes) else raf.setLength(0)

                body.byteStream().use { input ->
                    val buffer = ByteArray(64 * 1024)
                    var totalRead = if (resumed) existingBytes else 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        raf.write(buffer, 0, read)
                        totalRead += read
                        if (totalBytes > 0) onProgress((totalRead.toFloat() / totalBytes).coerceIn(0f, 1f))
                    }
                }
            }
        }
        tmp.renameTo(dest)
    }

    private fun updateState(info: ModelInfo, transform: (ModelDownloadState) -> ModelDownloadState) {
        _states.update { current ->
            val existing = current[info.name] ?: ModelDownloadState(
                info = info,
                status = if (isDownloaded(info)) DownloadStatus.DOWNLOADED else DownloadStatus.NOT_DOWNLOADED
            )
            current + (info.name to transform(existing))
        }
    }
}
