# Local AI Chat (Android)

Полноценное Android-приложение (Kotlin + Jetpack Compose) для общения с
локальными ИИ-моделями (LLM, формат GGUF через **llama.cpp**) прямо на
устройстве, без интернета — с поддержкой анализа изображений (Vision /
LLaVA) и бесконечной историей чата.

## Возможности

- Чат-интерфейс с потоковым выводом ответа (печатает токен за токеном)
- Загрузка LLM и Vision моделей из `models_manifest.json` с прогресс-баром
  и докачкой (Range-запросы)
- Камера и галерея для прикрепления изображений к сообщению
- Настройка температуры, top-p, top-k, системного промпта, размера контекста
- Скользящее окно контекста — диалог может длиться сколько угодно, в модель
  передаются последние N сообщений, вся история при этом хранится в
  `chat_history.json` на устройстве
- Библиотека готовых системных промптов (`system_prompts.json`)
- Экспорт настроек в `config.json`

## Архитектура

```
app/src/main/java/com/example/localai/
├── MainActivity.kt              — точка входа
├── data/Models.kt                — ChatMessage, ModelConfig, ModelInfo (+JSON (де)сериализация)
├── engine/
│   ├── LlamaBridge.kt             — JNI-обёртка (external fun)
│   ├── LocalAIEngine.kt           — оркестрация: загрузка модели, генерация, скользящий контекст
│   └── ModelDownloadManager.kt    — скачивание .gguf файлов (OkHttp, докачка, прогресс)
├── ui/
│   ├── ChatScreen.kt              — главный экран (чат + ввод + камера/галерея)
│   ├── ChatViewModel.kt           — состояние чата
│   ├── MessageBubble.kt           — пузырь сообщения с превью изображения
│   ├── SettingsPanel.kt           — параметры генерации
│   ├── ModelManagerScreen.kt      — список моделей, загрузка/удаление
│   └── theme/                     — цвета, типографика, Material3 тема
└── util/
    ├── HistoryStorage.kt          — JSON-файлы истории и конфига
    └── ManifestLoader.kt          — парсинг models_manifest.json

app/src/main/cpp/
├── CMakeLists.txt                 — сборка нативной библиотеки + подключение llama.cpp
└── llama_jni.cpp                  — мост Kotlin ↔ llama.cpp (+ заготовка под LLaVA)

app/src/main/assets/
├── config.json                    — настройки по умолчанию
├── models_manifest.json           — каталог моделей (имя, URL, размер)
└── system_prompts.json            — библиотека системных промптов
```

## ⚠️ Что нужно сделать перед сборкой APK

Этот архив содержит **весь прикладной код**, но не включает сам **llama.cpp**
(это отдельный C++ проект на тысячи файлов, его нужно подключить отдельно):

1. Установите **Android Studio** (Koala+) с **NDK 26.3** и **CMake 3.22**
   (Tools → SDK Manager → SDK Tools).

2. В корне проекта подключите llama.cpp как сабмодуль:
   ```bash
   cd LocalAIChat
   git init   # если ещё не git-репозиторий
   git submodule add https://github.com/ggerganov/llama.cpp app/src/main/cpp/llama.cpp
   git submodule update --init --recursive
   ```

3. Vision (LLaVA) подключается автоматически: `CMakeLists.txt` сам добавляет
   `app/src/main/cpp/llama.cpp/examples/llava` и линкует цели `clip`/`llava`,
   если они есть в вашей версии сабмодуля. Если сборка ругается, что цель
   не найдена — посмотрите актуальную структуру `examples/llava/CMakeLists.txt`
   в вашем коммите llama.cpp и поправьте имена целей в
   `app/src/main/cpp/CMakeLists.txt`.

4. Откройте проект в Android Studio → **File → Sync Project with Gradle Files**.
   Если llama.cpp не найден, проект всё равно соберётся в режиме **STUB_MODE**
   (отвечает тестовыми сообщениями) — удобно для проверки UI до полной
   интеграции модели.

5. Запустите на устройстве (рекомендуется реальный телефон с 6+ ГБ ОЗУ —
   эмулятор для LLM на 1.5–3B параметров будет очень медленным).

6. В приложении: **Настройки → Управление моделями** → скачайте LLM-модель
   (например, Qwen2.5 1.5B, ~1.1 ГБ) и, при желании, Vision-модель
   (LLaVA 1.6 Mistral 7B, ~4.4 ГБ — учитывайте объём ОЗУ устройства).

## Известные ограничения / что доработать

- `llama_jni.cpp` теперь содержит полный путь инференса **и для текста, и
  для изображений**: `clip_model_load()` грузит CLIP-проектор при старте,
  `llava_image_embed_make_with_filename()` + `llava_eval_image_embed()`
  кодируют картинку и подмешивают эмбеддинги в контекст перед текстом
  промпта (см. `examples/llava/llava.cpp` в самом llama.cpp).
- Имена и сигнатуры функций `clip_model_load`/`llava_eval_image_embed`,
  как и структура `examples/llava/CMakeLists.txt` (цели `clip`/`llava`),
  **отличаются между версиями llama.cpp** — если сборка не находит нужную
  цель или функцию, сверьтесь с версией вашего сабмодуля и поправьте
  `CMakeLists.txt` / `llama_jni.cpp` по образцу `examples/llava/llava-cli.cpp`.
- API основного текстового инференса (`llama_decode`, `llama_sampler_*`)
  актуален для свежих версий llama.cpp — при использовании другого коммита
  ориентируйтесь на `examples/simple/simple.cpp`.
- Чтобы модель не выгружалась при повороте экрана, в манифесте уже указан
  `configChanges` для Activity — для реального продакшена лучше вынести
  `LocalAIEngine` в `Application`-singleton.
- Прямого сброса kv-cache между независимыми диалогами сейчас нет —
  при необходимости можно добавить `llama_kv_cache_clear()`.

## Формат GGUF и список моделей

`models_manifest.json` уже содержит проверенные публичные ссылки на
HuggingFace (Qwen2.5, Phi-3.5, Gemma 2, LLaVA, Moondream2 — квантизация
Q4_K_M, подходит для мобильных устройств). Список можно редактировать —
структура самоописательная (`name`, `url`, опционально `mmprojUrl` для
vision-моделей).
